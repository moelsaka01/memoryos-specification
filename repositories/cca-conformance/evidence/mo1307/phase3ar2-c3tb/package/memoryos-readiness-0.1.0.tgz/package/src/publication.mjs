import fs from 'node:fs/promises';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { DEFINITIONS } from './constants.mjs';
import { fail, ReadinessError } from './errors.mjs';
import { consumePublicationInspection, inspectPublication } from './helper-protocol.mjs';
import { assertComponentChain, assertStableIdentity, resolveContained, validateAbsoluteRoot } from './windows-paths.mjs';

const FINAL = 'memoryos-readiness-result.json';
const PENDING = FINAL + '.pending';
const tokens = new WeakMap();
const limit = DEFINITIONS.limits.resultBytes;
function output() { fail('OUTPUT', 'PUBLICATION', null); }
function stateOf(token) {
  if (!token || typeof token !== 'object' || !tokens.has(token)) output();
  return tokens.get(token);
}
async function guarded(action) {
  try { return await action(); } catch (error) {
    if (error instanceof ReadinessError && ['MO1307_TIMEOUT', 'MO1307_CANCELLED'].includes(error.code)) throw error;
    output();
  }
}
async function chainAt(inspection, operation, root, relative = null) {
  const chain = await inspectPublication(inspection, operation);
  assertComponentChain(root, relative, chain, { stage: 'PUBLICATION' });
  return structuredClone(chain);
}
function sameChain(before, after) {
  if (before.length !== after.length) output();
  before.forEach((identity, index) => assertStableIdentity(identity, after[index], {
    directory: identity.isDirectory, stage: 'PUBLICATION',
  }));
}
function invalidate(state) {
  if (!state.admitted) {
    state.failed = true; state.phase = 'FAILED';
    state.stopPendingWrite?.(new ReadinessError('OUTPUT', 'PUBLICATION'));
  }
  state.consumed = true; output();
}
function checkpoint(state) {
  if (state.failed) output();
  if (state.interruptionBeforeAdmission !== null) fail(state.interruptionBeforeAdmission, 'PUBLICATION', null);
  // Admission remains strictly before the deadline. Once submitted, the exact
  // non-cancellable rename must settle; it must never be raced by this check.
  state.checkpoint();
}

// Clear on the first interruption even if an abort-aware write settles later.
async function writePending(handle, bytes, state) {
  const abort = new AbortController();
  let interrupted = null;
  const stopWrite = error => {
    interrupted ??= error; clearInterval(timer); abort.abort();
  };
  const timer = setInterval(() => {
    try { checkpoint(state); } catch (error) { stopWrite(error); }
  }, 5);
  state.stopPendingWrite = stopWrite;
  try {
    await handle.writeFile(bytes, { signal: abort.signal });
    if (interrupted) throw interrupted;
    checkpoint(state);
  } catch (error) { throw interrupted ?? error; }
  finally { clearInterval(timer); state.stopPendingWrite = null; }
}

// Operational observations only: none enters normative result/proof identity.
export function publicationStatus(token) {
  const state = stateOf(token);
  return Object.freeze({ phase: state.phase, admitted: state.admitted,
    deadlineExpiredAfterAdmission: state.deadlineExpiredAfterAdmission,
    cancelledAfterAdmission: state.cancelledAfterAdmission, namespaceVerified: state.namespaceVerified,
    dispositionDeadline: state.dispositionDeadline });
}
export function recordPublicationInterruption(token, code) {
  const state = stateOf(token);
  if (!['MO1307_TIMEOUT', 'MO1307_CANCELLED'].includes(code)) output();
  if (!state.admitted) {
    state.interruptionBeforeAdmission ??= code.slice(7);
    // Supervisor stop notification clears operation-owned polling before it
    // returns to the caller, even when writeFile itself has not settled yet.
    state.stopPendingWrite?.(new ReadinessError(state.interruptionBeforeAdmission, 'PUBLICATION'));
  }
  else if (code === 'MO1307_TIMEOUT') state.deadlineExpiredAfterAdmission = true;
  else state.cancelledAfterAdmission = true;
  return publicationStatus(token);
}
function observeAfterAdmission(state) {
  // An earlier observed interruption is already terminal for transport. The
  // pre-admission helper sequence may have been invalidated by that observation.
  if (state.deadlineExpiredAfterAdmission || state.cancelledAfterAdmission) return;
  try { state.checkpoint(); } catch (error) {
    if (error instanceof ReadinessError && error.code === 'MO1307_TIMEOUT') state.deadlineExpiredAfterAdmission = true;
    else if (error instanceof ReadinessError && error.code === 'MO1307_CANCELLED') state.cancelledAfterAdmission = true;
    else output();
  }
}
export function publicationTransportCheckpoint(token) {
  const state = stateOf(token);
  if (state.phase !== 'COMMITTED' || !state.namespaceVerified) output();
  observeAfterAdmission(state);
  if (state.deadlineExpiredAfterAdmission || state.cancelledAfterAdmission) output();
}

async function confirmSettledNamespace(state, committed) {
  // Supplemental read-only confirmation under the already checked native
  // chain/private-root authority. This does not perform another native check.
  // The existing 2s cleanup number bounds disposition after rename settlement;
  // no timer bounds or cancels the rename itself. Expired reads can only close
  // their handle later, never mutate or publish the pending/final namespace.
  const deadline = state.dispositionDeadline;
  let expired = false; let timer;
  const check = () => { if (expired || performance.now() >= deadline) output(); };
  const verify = (async () => {
    const present = path.win32.join(state.root, committed ? FINAL : PENDING);
    const absent = path.win32.join(state.root, committed ? PENDING : FINAL);
    const handle = await fs.open(present, 'r');
    try {
      check();
      const stat = await handle.stat(); check();
      if (!stat.isFile() || stat.nlink !== 1 || stat.size !== state.bytes.byteLength) output();
      const bytes = Buffer.alloc(state.bytes.byteLength + 1);
      let used = 0;
      while (used < bytes.length) {
        check();
        const { bytesRead } = await handle.read(bytes, used, bytes.length - used, used);
        check();
        if (bytesRead === 0) break;
        used += bytesRead;
      }
      if (used !== state.bytes.byteLength || !bytes.subarray(0, used).equals(state.bytes)) output();
    } finally { await handle.close(); }
    check();
    try { await fs.lstat(absent); } catch (error) {
      check();
      if (error.code === 'ENOENT') return;
      throw error;
    }
    output();
  })();
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => { expired = true; reject(new ReadinessError('OUTPUT', 'PUBLICATION')); },
      Math.max(0, deadline - performance.now()));
  });
  try {
    await Promise.race([verify, timeout]);
    check(); state.namespaceVerified = true;
  } finally { expired = true; clearTimeout(timer); }
}

// Only a branded, single-claim inspection capability from the completed
// acquisition/worker lifecycle can authorize publication. Every observation is
// represented by one closed framed helper operation; no implicit native hook
// or Node-only reparse/absence authority exists. This primitive launches no
// helper and does not implement the Phase 2C acquisition supervisor.
export async function createPublication(root, { inspection } = {}) {
  return guarded(async () => {
    root = validateAbsoluteRoot(root, { stage: 'PUBLICATION' });
    resolveContained(root, PENDING, { stage: 'PUBLICATION' });
    const check = consumePublicationInspection(inspection, root);
    const parent = path.win32.dirname(root);
    if (parent === root) output();
    const before = await chainAt(inspection, 'CHECK_OUTPUT', parent);
    check();
    // No recursive mkdir and no pre-existing destination is accepted.
    await fs.mkdir(root, { recursive: false, mode: 0o700 });
    check();
    const created = await chainAt(inspection, 'INSPECT_OUTPUT_ROOT', root);
    sameChain(before, created.slice(0, -1));
    check();
    const token = Object.freeze(Object.create(null));
    tokens.set(token, { root, inspection, checkpoint: check, chain: created, pendingChain: null,
      bytes: null, staged: false, consumed: false, busy: false, failed: false, stopPendingWrite: null, phase: 'PRE_SUBMISSION', admitted: false,
      interruptionBeforeAdmission: null, deadlineExpiredAfterAdmission: false,
      cancelledAfterAdmission: false, namespaceVerified: false, dispositionDeadline: null });
    return token;
  });
}

export async function stagePublication(token, input) {
  const state = stateOf(token);
  if (state.consumed || state.staged || state.busy || state.failed) invalidate(state);
  state.busy = true;
  try {
    return await guarded(async () => {
      if (!(input instanceof Uint8Array) || input.buffer instanceof SharedArrayBuffer
          || input.byteLength === 0 || input.byteLength > limit
          || input.byteLength > DEFINITIONS.limits.temporaryOutputBytes) output();
      const bytes = Buffer.from(input);
      checkpoint(state);
      sameChain(state.chain, await chainAt(state.inspection, 'CHECK_STAGE_ROOT', state.root));
      const pending = path.win32.join(state.root, PENDING);
      checkpoint(state);
      // Exclusive creation prevents replacement even before the commit point.
      const handle = await fs.open(pending, 'wx+', 0o600);
      try {
        checkpoint(state);
        await writePending(handle, bytes, state);
        checkpoint(state);
        await handle.sync();
        checkpoint(state);
        const stat = await handle.stat();
        checkpoint(state);
        if (!stat.isFile() || stat.nlink !== 1 || stat.size !== bytes.byteLength) output();
        const verify = Buffer.alloc(bytes.byteLength + 1);
        let used = 0;
        while (used < verify.length) {
          checkpoint(state);
          const { bytesRead } = await handle.read(verify, used, verify.length - used, used);
          checkpoint(state);
          if (bytesRead === 0) break;
          used += bytesRead;
        }
        if (used !== bytes.byteLength || !verify.subarray(0, used).equals(bytes)) output();
      } finally { await handle.close(); }
      checkpoint(state);
      const pendingChain = await chainAt(state.inspection, 'INSPECT_PENDING', state.root, PENDING);
      sameChain(state.chain, pendingChain.slice(0, -1));
      if (pendingChain.at(-1).byteLength !== bytes.byteLength) output();
      checkpoint(state);
      state.bytes = bytes; state.pendingChain = pendingChain; state.staged = true;
    });
  } catch (error) { state.failed = true; state.phase = 'FAILED'; state.consumed = true; throw error; }
  finally { state.busy = false; }
}

export async function finalizePublication(token) {
  const state = stateOf(token);
  if (state.consumed || !state.staged || state.busy || state.failed) invalidate(state);
  state.consumed = true;
  return guarded(async () => { try {
    checkpoint(state);
    const pending = path.win32.join(state.root, PENDING);
    const final = path.win32.join(state.root, FINAL);
    const handle = await fs.open(pending, 'r');
    try {
      checkpoint(state);
      const stat = await handle.stat();
      checkpoint(state);
      if (!stat.isFile() || stat.nlink !== 1 || stat.size !== state.bytes.byteLength) output();
      const verify = Buffer.alloc(state.bytes.byteLength + 1);
      let used = 0;
      while (used < verify.length) {
        checkpoint(state);
        const { bytesRead } = await handle.read(verify, used, verify.length - used, used);
        checkpoint(state);
        if (bytesRead === 0) break;
        used += bytesRead;
      }
      if (used !== state.bytes.byteLength || !verify.subarray(0, used).equals(state.bytes)) output();
    } finally { await handle.close(); }
    // One native operation checks the full pending chain and final absence
    // after the final exact-byte read has closed its handle.
    checkpoint(state);
    const finalChain = await chainAt(state.inspection, 'CHECK_FINALIZATION', state.root, PENDING);
    sameChain(state.chain, finalChain.slice(0, -1));
    sameChain(state.pendingChain, finalChain);
    checkpoint(state);
    // Windows Node rename has kernel replacement capability. Nonreplacement
    // here depends explicitly on Freeze §17's private/exclusive host roots and
    // exclusion of concurrent adversarial namespace mutation: exact identity
    // and absence are checked, and the single-use token prevents our own retry
    // or overlapping publication. This is not a race-proof syscall guarantee
    // against a concurrent attacker excluded by that frozen precondition.
    // This same-turn admission-and-submission section has no await, observer
    // hook or caller callback between the final checkpoint and rename. Actual
    // success, not submission or a timeout, remains the sole commit point.
    state.admitted = true; state.phase = 'COMMIT_IN_PROGRESS';
    let committed = false;
    try {
      await fs.rename(pending, final);
      committed = true; state.phase = 'COMMITTED';
    } catch {
      state.phase = 'FAILED';
    }
    state.dispositionDeadline = performance.now() + DEFINITIONS.limits.cleanupAllowanceMs;
    // From admission onward no path returns TIMEOUT/CANCELLED. No cleanup
    // mutation, second rename, helper or worker is permitted during settlement.
    try {
      observeAfterAdmission(state);
      await confirmSettledNamespace(state, committed);
      observeAfterAdmission(state);
    } catch { output(); }
    if (!committed) output();
    return Object.freeze({ path: final, byteLength: state.bytes.byteLength });
  } catch (error) {
    if (!state.admitted) state.phase = 'FAILED';
    if (state.admitted) output();
    throw error;
  }
  });
}
